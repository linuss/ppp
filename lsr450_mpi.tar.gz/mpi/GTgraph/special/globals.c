#include "globals.h"

/* Global variables */
int GRAPH_MODEL;
int ORIENTED = 0; 

LONG_T n;
LONG_T m;

int size=1; 
int out_degree=10;

WEIGHT_T MAX_WEIGHT;
WEIGHT_T MIN_WEIGHT;

int SELF_LOOPS;

int STORE_IN_MEMORY=1;

int SORT_EDGELISTS;
int SORT_TYPE;
int WRITE_TO_FILE;

char OUTFILE[30];
//PPP
char NEWFILE[34];
char LOGFILE[30];
